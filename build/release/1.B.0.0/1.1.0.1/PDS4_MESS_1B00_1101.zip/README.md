# Build 1.B.0.0 of version 1.1.0.1 of the [MESSENGER Mission Local Data Dictionary](https://github.com/nasa-pds/ldd-messenger)

This build is compatible with version 1.B.0.0 and later of the core [PDS4 Information Model](https://pds.nasa.gov/pds4/doc/im/).